var main = function() { 
	$('.moreButtonDiv').click(function() {
			//$(this).parent().find('.bottom').toggle();
			$(this).parents('div').find('.bottom').toggle();
			//$(":parent")
		});
	//alert('test');
};


$(document).ready(main);